import argparse
from bot.client import BinanceClient
from bot.orders import place_order
from bot.logging_config import setup_logger

def main():
    setup_logger()

    parser = argparse.ArgumentParser(
        description="Simple Binance Futures Testnet Trading Bot"
    )

    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True, choices=["BUY", "SELL"])
    parser.add_argument("--type", required=True, choices=["MARKET", "LIMIT"])
    parser.add_argument("--quantity", required=True, type=float)
    parser.add_argument("--price", type=float)

    args = parser.parse_args()

    client = BinanceClient()

    print("\n📤 Order Request")
    print(f"Symbol: {args.symbol}")
    print(f"Side: {args.side}")
    print(f"Type: {args.type}")
    print(f"Quantity: {args.quantity}")
    if args.type == "LIMIT":
        print(f"Price: {args.price}")

    try:
        result = place_order(
            client=client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price
        )

        print("\n✅ Order Placed Successfully")
        print("Order ID:", result.get("orderId"))
        print("Status:", result.get("status"))
        print("Executed Qty:", result.get("executedQty"))
        print("Average Price:", result.get("avgPrice"))

    except Exception as err:
        print("\n❌ Order Failed")
        print(str(err))

if __name__ == "__main__":
    main()
