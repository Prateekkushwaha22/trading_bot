"""
bot package

This package contains all core logic related to:
- Binance client
- Order placement
- Input validation
"""

from .client import BinanceClient
from .orders import place_order
